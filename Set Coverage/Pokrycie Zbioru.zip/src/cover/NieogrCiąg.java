package cover;
public class NieogrCiąg extends Składnik{
    int wartośćPoczątkowa, przyrost;
    NieogrCiąg(int wartośćPoczątkowa, int przyrost) {
        this.wartośćPoczątkowa = wartośćPoczątkowa;
        this.przyrost = przyrost;
    }

    boolean czyIstnieje(int wartość) {
        return (wartość >= wartośćPoczątkowa &&
                (wartość - wartośćPoczątkowa) % przyrost == 0);
    }
}
