package cover;

// z podklas tego elementu składa się cały zbiór
// jest nadklasą elementu, ciągu ograniczonego oraz ciągu nieograniczonego
public abstract class Składnik {
    // sprawdza czy zadana wartość istnieje w którejś z podklas
    abstract boolean czyIstnieje(int wartość);
}
