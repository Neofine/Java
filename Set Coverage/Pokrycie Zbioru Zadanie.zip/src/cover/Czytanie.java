package cover;

import java.util.ArrayList;
import java.util.Scanner;

public class Czytanie {
    public static void czytaj(Scanner scan, ArrayList <Integer> wejście) {
        while(scan.hasNextLine()) {
            String linia[] = scan.nextLine().trim().split("\\s+");
            for (String i: linia) {
                if (!i.isBlank())
                    wejście.add(Integer.parseInt(i));
            }
        }
    }
}
